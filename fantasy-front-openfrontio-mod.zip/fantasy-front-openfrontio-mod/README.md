# Fantasy Mode implementation slice

This package is intended to be copied into a writable fork of
[openfrontio/OpenFrontIO](https://github.com/openfrontio/OpenFrontIO).

- `packages/fantasy-mode/data/fantasy-mode.json`: canonical design data
- `packages/fantasy-mode/data/fantasy-mode.schema.json`: JSON schema
- `packages/fantasy-mode/src/types.ts`: TypeScript contracts and validator
- `packages/fantasy-mode/src/index.ts`: package entry point
- `docs/FANTASY_MODE_INTEGRATION.md`: engine integration plan

The upstream source remains unchanged by this package. See the integration guide before
connecting the package to server-authoritative simulation or versioned replay schemas.
