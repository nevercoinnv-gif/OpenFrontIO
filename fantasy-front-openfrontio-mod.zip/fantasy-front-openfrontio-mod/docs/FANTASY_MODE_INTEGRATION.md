# Fantasy Mode — OpenFrontIO adaptation

This folder is the first isolated implementation slice for the fantasy strategy adaptation.
It deliberately preserves the OpenFront-style territory-control core and does not modify
OpenFront's production engine or wire protocol yet.

## Included
- Eight balanced races: Humans, Orcs, Elves, Dwarves, Demons, Dragonkin, Vampires, Angels.
- Five shared unit classes for every race: infantry, ranged, cavalry, mages, siege.
- Race-specific display names for those shared classes.
- One passive and one mana/cooldown-gated active ability per race.
- Generic spells with mana, cooldown and cast-time metadata.
- Match and persistent-world configuration targets.
- TypeScript data contracts and a balance/config validator.

## Balance constraints
- Race stats remain in the 92–110 band (baseline 100).
- Passive modifiers are capped at 10% by design.
- All races can spawn on all continents.
- Magic supplements armies; it does not replace the territory/army loop.
- The engine remains authoritative: clients must never decide combat results.

## Integration plan
1. Add a `fantasyMode` selection to a versioned game configuration (not an unversioned
   wire field) and validate it on the server.
2. Persist the selected race in player/nation state and snapshots so replays stay deterministic.
3. Introduce a `mana` resource with deterministic server-side income, caps and spending.
4. Add typed spell intents with target validation, mana checks, cooldown checks and telegraph times.
5. Extend combat calculations with race modifiers at a single authoritative point.
6. Replace visual assets and labels after simulation semantics are stable.
7. Add regression tests for all eight races and ensure classic OpenFront mode remains unchanged.

## Important
This is a foundation package, not yet a complete playable conversion. It does not yet wire
race selection into the lobby, change the production battle formulas, add live multiplayer
spells, replace nuclear attack execution, or deliver the anime art assets. Those changes need
targeted integration and CI/testing inside a writable fork of the upstream repository.
