import data from "../data/fantasy-mode.json";
import { validateFantasyMode, type FantasyModeData } from "./types";

export * from "./types";

export const fantasyMode = data as FantasyModeData;

const validationErrors = validateFantasyMode(fantasyMode);
if (validationErrors.length > 0) {
  throw new Error(`Invalid fantasy mode configuration:\\n${validationErrors.join("\\n")}`);
}
