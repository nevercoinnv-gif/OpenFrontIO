/**
 * Fantasy Mode data types and balance-safe helpers.
 *
 * This package is intentionally isolated from OpenFront's authoritative engine.
 * Integrate via explicit game configuration and validated intents after gameplay
 * semantics, snapshots, replay compatibility and server validation are reviewed.
 */
export type FantasyRaceId =
  | "humans" | "orcs" | "elves" | "dwarves"
  | "demons" | "dragonkin" | "vampires" | "angels";

export type FantasyUnitClass =
  | "infantry" | "ranged" | "cavalry" | "mages" | "siege";

export interface RaceStats {
  attack: number;
  defense: number;
  speed: number;
  magic: number;
  economy: number;
}

export interface RaceModifier {
  infantryAttack?: number;
  rangedEffectiveRange?: number;
  fortificationHealth?: number;
  offensiveSpellDamage?: number;
  heavyFireResistance?: number;
  recoverableCasualties?: number;
  magicResistance?: number;
  armyCompositionChangeCost?: number;
}

export interface FantasyAbility {
  id: string;
  label: string;
  description: string;
  manaCost: number;
  cooldownSeconds: number;
  durationSeconds: number;
  effect: Record<string, number>;
  crystalCost?: number;
}

export interface FantasyRace {
  id: FantasyRaceId;
  name: string;
  displayName: string;
  role: string;
  stats: RaceStats;
  passive: {
    id: string;
    label: string;
    description: string;
    modifiers: RaceModifier;
  };
  active: FantasyAbility;
}

export interface FantasyModeData {
  version: 1;
  designRules: {
    sharedCore: boolean;
    raceBalance: "limited-differences";
    statRange: { min: number; max: number };
    maxPassiveModifier: number;
    allRacesCanSpawnOnAllContinents: boolean;
    magicDoesNotReplaceArmies: boolean;
    manaAndCooldownRequired: boolean;
    matchAndPersistentModesShareSimulation: boolean;
  };
  races: FantasyRace[];
  unitClasses: Array<{
    id: FantasyUnitClass;
    displayName: string;
    role: string;
    counter: FantasyUnitClass;
    shared: true;
  }>;
  raceUnitNames: Record<FantasyRaceId, string[]>;
  spells: Array<{
    id: string;
    name: string;
    type: string;
    manaCost: number;
    cooldownSeconds: number;
    castSeconds: number;
    description: string;
    crystalCost?: number;
  }>;
  modes: {
    match: {
      independentSession: true;
      targetPlayers: { min: number; max: number };
      targetDurationMinutes: { min: number; max: number };
      victoryTerritoryPercent: number;
      failure: string;
    };
    persistent: {
      worldSize: string;
      continents: number;
      targetRegions: number;
      failure: string;
      sharedHistory: true;
    };
  };
  resources: {
    match: string[];
    persistent: string[];
  };
}

export function validateFantasyMode(data: FantasyModeData): string[] {
  const errors: string[] = [];
  const expected: FantasyRaceId[] = [
    "humans", "orcs", "elves", "dwarves",
    "demons", "dragonkin", "vampires", "angels",
  ];
  if (data.version !== 1) errors.push("Unsupported fantasy mode data version.");
  if (data.races.length !== 8) errors.push("Exactly eight races are required.");
  if (data.unitClasses.length !== 5) errors.push("Exactly five shared unit classes are required.");
  const ids = new Set(data.races.map((race) => race.id));
  for (const id of expected) if (!ids.has(id)) errors.push(`Missing race: ${id}`);
  for (const race of data.races) {
    const values = Object.values(race.stats);
    if (values.some((value) => !Number.isFinite(value) || value < data.designRules.statRange.min || value > data.designRules.statRange.max)) {
      errors.push(`Race ${race.id} has a stat outside the allowed balance range.`);
    }
    if (race.active.manaCost < 0 || race.active.cooldownSeconds <= 0) {
      errors.push(`Race ${race.id} has an invalid active ability cost or cooldown.`);
    }
  }
  for (const unit of data.unitClasses) {
    if (!data.unitClasses.some((candidate) => candidate.id === unit.counter)) {
      errors.push(`Unit ${unit.id} has an invalid counter class.`);
    }
  }
  for (const race of expected) {
    if ((data.raceUnitNames[race] ?? []).length !== 5) {
      errors.push(`Race ${race} must name all five shared unit classes.`);
    }
  }
  if (!data.designRules.allRacesCanSpawnOnAllContinents) errors.push("Race spawn must remain continent-independent.");
  if (!data.designRules.magicDoesNotReplaceArmies) errors.push("Magic must not replace the army core loop.");
  return errors;
}
